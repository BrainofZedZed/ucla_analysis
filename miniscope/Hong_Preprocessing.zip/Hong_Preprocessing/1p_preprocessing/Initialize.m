%%
xz_folder = fileparts(mfilename('fullpath'));
addpath(genpath(xz_folder));


