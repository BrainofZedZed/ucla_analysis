function minute_str = get_minute()

minute_str = datestr(datetime('now'), 'HH:MM:SS');
