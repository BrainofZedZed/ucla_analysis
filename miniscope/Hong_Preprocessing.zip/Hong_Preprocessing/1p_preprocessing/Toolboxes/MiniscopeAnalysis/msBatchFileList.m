/Users/guillaume/very_nice_data/mouse-45/H07_M45_S02/
