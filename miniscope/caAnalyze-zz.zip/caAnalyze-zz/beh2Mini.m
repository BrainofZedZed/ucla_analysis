% beh2Mini: post-BehaviorDEPOT Script for FRLU Generation and Miniscope-Aligned Prep

function caBehavior = beh2Mini(Behavior, Behavior_Filter, Metrics, frlu, total_ca_frames)
% Create a copy of data (for adjustment)
caBehavior = struct();

% Use lookup table to convert annotations in tempBehavior
behavs = fieldnames(Behavior);

num_frames = total_ca_frames;
beh2ca = frlu(:,2);

for i = 1:size(behavs, 1)
    % convert behavior bouts from behavior frames to miniscope frames
    bouts = beh2ca(Behavior.(behavs{i}).Bouts);
    
    % save to outbound struct
    caBehavior.(behavs{i}) = genBehStruct(bouts(:,1), bouts(:,2), num_frames);
    
end


% Save caBehavior struct
save('caBehavior.mat', 'caBehavior')

end