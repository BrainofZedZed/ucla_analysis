# caAnalyze
All-in-one analysis package for analyzing extracted calcium signals (+ integration with BehaviorDEPOT)
